export class Admin{
    public constructor(init?: Partial<Admin>) {
        Object.assign(this, init);
    }

    
}