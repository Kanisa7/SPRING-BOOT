package com.xfactor.openlibrary;

public @interface SpringBootTest {

}
