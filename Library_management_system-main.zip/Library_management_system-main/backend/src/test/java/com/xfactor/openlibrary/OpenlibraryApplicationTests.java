package com.xfactor.openlibrary;

@SpringBootTest
class OpenlibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}